import os.path as ops
import torch
import lib
from lib.models import axialnet
import argparse
import torch
import torchvision
from torch import nn
from torch.autograd import Variable
from torch.utils.data import DataLoader
from torchvision import transforms
from torchvision.utils import save_image
import torch.nn.functional as F
import os
import matplotlib.pyplot as plt
import torch.utils.data as data
from PIL import Image
import numpy as np
from torchvision.utils import save_image
import torch
import torch.nn.init as init
from outside.utils import JointTransform2D, ImageToImage2D, Image2D
from outside.metrics import jaccard_index, f1_score, LogNLLLoss, classwise_f1
from outside.utils import chk_mkdir, Logger, MetricList
import cv2
from functools import partial
from random import randint
import timeit
from tqdm import tqdm
from model.loss import SoftLoULoss
from model.metrics import SigmoidMetric, SamplewiseSigmoidMetric



def parse_args():
    parser = argparse.ArgumentParser(description='RWLGA')
    parser.add_argument('-j', '--workers', default=8, type=int, metavar='N',
                        help='number of data loading workers (default: 8)')
    parser.add_argument('--epochs', default='int', type=int, metavar='N',
                        help='number of total epochs to run(default: 400)')
    parser.add_argument('--start-epoch', default=0, type=int, metavar='N',
                        help='manual epoch number (useful on restarts)')
    parser.add_argument('-b', '--batch_size', default=8, type=int,
                        metavar='N', help='batch size (default: 1)')
    parser.add_argument('--learning_rate', default=1e-3, type=float,
                        metavar='LR', help='initial learning rate')
    parser.add_argument('--momentum', default=0.9, type=float, metavar='M',
                        help='momentum')
    parser.add_argument('--weight-decay', '--wd', default=1e-5, type=float,
                        metavar='W', help='weight decay (default: 1e-5)')
    parser.add_argument('--train_dataset', default='str', type=str)
    parser.add_argument('--val_dataset', default='str', type=str)
    parser.add_argument('--save_freq', type=int, default=int)
    parser.add_argument('--modelname', default='RWLGA', type=str,
                        help='type of model')
    parser.add_argument('--cuda', default="on", type=str,
                        help='switch on/off cuda option (default: off)')
    parser.add_argument('--aug', default='off', type=str,
                        help='turn on img augmentation (default: False)')
    parser.add_argument('--load', default='default', type=str,
                        help='load a pretrained model')
    parser.add_argument('--save', default='default', type=str,
                        help='save the model')
    parser.add_argument('--direc', default='str', type=str,
                        help='directory to save')
    parser.add_argument('--imgchant', default= 3, type=int)
    parser.add_argument('--crop', type=int, default=None)
    parser.add_argument('--imgsize', type=int, default='INT')
    parser.add_argument('--device', default='cuda', type=str)
    parser.add_argument('--score-thresh', type=float, default=0.5,
                        help='score-thresh')
    parser.add_argument('--gpus', type=str, default='2',
                        help='Training with GPUs, you can specify 1,3 for example.')
    args = parser.parse_args()

    return args


class Trainer(object):
    def __init__(self, args):
        self.args = args

        self.aug = args.aug
        self.direc = args.direc
        self.modelname = args.modelname
        self.imgsize = args.imgsize
        self.imgchant = args.imgchant
        self.save_pkl = ops.join(self.direc, 'model_model')
        if not ops.exists(self.save_pkl):
            os.mkdir(self.save_pkl)

        if args.crop is not None:
            crop = (args.crop, args.crop)
        else:
            crop = None

        tf_train = JointTransform2D(crop=crop, p_flip=0.5,  p_random_affine=0, color_jitter_params=None, long_mask=True)
        tf_val = JointTransform2D(crop=None, p_flip=0, p_random_affine=0, color_jitter_params=None, long_mask=True)
        self.train_dataset = ImageToImage2D(args.train_dataset, tf_train)
        self.val_dataset = ImageToImage2D(args.val_dataset, tf_val)
        self.dataloader = DataLoader(self.train_dataset, batch_size=args.batch_size, shuffle=True)
        self.valloader = DataLoader(self.val_dataset, 4, shuffle=True)

        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        if self.modelname == "RWLGA":
            self.model = lib.models.axialnet.RWLGA(img_size=args.imgsize, imgchan=args.imgchant)

        if torch.cuda.device_count() > 1:
            print("Let's use", torch.cuda.device_count(), "GPUs!")
            self.model = nn.DataParallel(self.model, device_ids=[0, 1]).cuda()

        self.model.to(device)
        self.criterion = LogNLLLoss()
        self.optimizer = torch.optim.Adam(list(self.model.parameters()), lr=args.learning_rate,weight_decay=1e-5)
        ## evaluation metrics
        self.iou_metric = SigmoidMetric()
        self.best_iou = 0
        self.best_nIoU = 0
        pytorch_total_params = sum(p.numel() for p in self.model.parameters() if p.requires_grad)
        print("Total_params: {}".format(pytorch_total_params))
        seed = 3000
        np.random.seed(seed)
        torch.manual_seed(seed)
        torch.cuda.manual_seed(seed)

    def training(self, epoch):

         self.model.train()

         tbar = tqdm(self.dataloader)

         epoch_running_loss = 0

         for batch_idx, (X_batch, y_batch, *rest) in enumerate(tbar):
                X_batch = Variable(X_batch.to(device='cuda'))
                y_batch = Variable(y_batch.to(device='cuda'))
                # ===================forward=====================
                output = self.model(X_batch)
                loss = self.criterion(output, y_batch)
                # ===================backward====================
                self.optimizer.zero_grad()
                loss.backward()
                self.optimizer.step()
                epoch_running_loss += loss.item()
                tbar.set_description('Epoch:%3d, train loss:%f' % (epoch, epoch_running_loss / (batch_idx + 1)))
            # ===================log========================
         if (epoch % args.save_freq) == 0:
                fulldir = self.direc + "/{}/".format(epoch)
                if not os.path.isdir(fulldir):
                    os.makedirs(fulldir)
                torch.save(self.model.state_dict(), fulldir + args.modelname + ".pth")
    def validation(self, epoch):
        self.iou_metric.reset()
        self.model.eval()
        eval_losses = []
        nIoU = []
        tbar = tqdm(self.valloader)
        for batch_idx, (X_batch, y_batch, *rest) in enumerate(tbar):

                if isinstance(rest[0][0], str):
                    image_filename = rest[0][0]
                else:
                    image_filename = '%s.png' % str(batch_idx + 1).zfill(3)
                X_batch = Variable(X_batch.to(device='cuda'))
                y_batch = Variable(y_batch.to(device='cuda'))
                y_out = self.model(X_batch)
                loss = self.criterion(y_out, y_batch)
                eval_losses.append(loss.item())
                y_out = y_out.detach().cpu()
                y_batch = y_batch.detach().cpu()

                y_out1 = y_out
                y_batch = y_batch.unsqueeze(dim=1)
                y_out11, y_out12 = y_out1.split([1, 1], dim=1)
                y_out12[y_out12 >= 0.5] = 1
                y_out12[y_out12 < 0.5] = 0
                self.iou_metric.update(y_out12, y_batch)
                _, IoU = self.iou_metric.get()
                nIoU.append(IoU.item())
                tbar.set_description(
                    ' Epoch:%3d, eval loss:%f,IoU:%f, nIoU:%f' % (epoch, np.mean(eval_losses), IoU,  np.mean(nIoU)))
                pkl_name = 'Epoch-%3d_IoU-%.4f.pth' % (epoch, IoU)
                if IoU > self.best_iou:
                    torch.save(self.model.state_dict(), ops.join(self.save_pkl, pkl_name))
                    self.best_iou = IoU
                if (epoch % args.save_freq) == 0:
                    tmp = y_out.numpy()
                    tmp[tmp > 0.5] = 1
                    tmp[tmp <= 0.5] = 0
                    tmp = tmp.astype(int)
                    yHaT = tmp
                    del X_batch, y_batch, tmp, y_out
                    yHaT[yHaT == 1] = 255
                    fulldir = self.direc + "/{}/".format(epoch)
                    if not os.path.isdir(fulldir):
                        os.makedirs(fulldir)
                    cv2.imwrite(fulldir + image_filename, yHaT[0, 1, :, :])
        nIoU = np.mean(nIoU)
        pkl_name = 'Epoch-%3d_best_IoU-%.4f_nIoU-%.4f.pth' % (epoch, self.best_iou, nIoU)
        if nIoU > self.best_nIoU:
            torch.save(self.model.state_dict(), ops.join(self.save_pkl, pkl_name))
            self.best_nIoU = nIoU
if __name__ == '__main__':
    args = parse_args()

    trainer = Trainer(args)
    for epoch in range(0, args.epochs):
        trainer.training(epoch)
        trainer.validation(epoch)

    print('Best IoU: %.5f, best nIoU: %.5f' % (trainer.best_iou, trainer.best_nIoU))
